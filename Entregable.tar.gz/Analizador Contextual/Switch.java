class Factorial {
    public static void main(String[] a) {
        System.out.println(new Fac().ComputeFac(10));
    }
}
class Fac {
    public int ComputeFac(int num) {
        int num_aux;
	switch (num_aux) {
		case 1':'
			algo = 1;
	}
        return num_aux;
    }
}
