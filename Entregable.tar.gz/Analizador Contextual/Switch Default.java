class Factorial {
    public static void main(String[] a) {
        System.out.println(new Fac().ComputeFac(10));
    }
}
class Fac {
    public int ComputeFac(int num) {
        int num_aux;
		string string_aux;
		
	switch (num_aux) {
		case 1':'
			algo = 1;
		case 2':'
			algo = 2;
		case 3':'
			algo = 3;
		default':'
			algo = 4;
	}
        return num_aux;
    }
}
